const $ = (id) => document.getElementById(id);
let projectId = null;
let selectedFile = null;
const api = async (path, options={}) => {
  const response = await fetch(`/api/v1${path}`, options);
  const data = await response.json().catch(()=>({detail:`Request failed (${response.status})`}));
  if (!response.ok) throw new Error(data.detail || `Request failed (${response.status})`);
  return data;
};
function notice(id, message, kind='') { const el=$(id); el.textContent=message; el.className=`notice ${kind}`; }
function show(id) { $(id).classList.remove('hidden'); }
function hide(id) { $(id).classList.add('hidden'); }
function busy(button, active, label) { button.disabled=active; if(active) button.dataset.old=button.innerHTML; button.innerHTML=active?`${label} <span>…</span>`:button.dataset.old||button.innerHTML; }
$('create-btn').addEventListener('click', async()=>{
  const title=$('project-title').value.trim(); if(!title){notice('create-notice','Enter a project title.','error');return;}
  const btn=$('create-btn');busy(btn,true,'Creating');
  try{const p=await api('/projects',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,art_style:$('art-style').value})});projectId=p.id;show('upload-card');notice('create-notice',`Project created: ${p.title}`,'good');$('upload-card').scrollIntoView({behavior:'smooth',block:'start'});}
  catch(e){notice('create-notice',e.message,'error');}finally{busy(btn,false);}
});
$('novel-file').addEventListener('change',e=>{selectedFile=e.target.files[0]||null;$('file-label').textContent=selectedFile?`${selectedFile.name} · ${(selectedFile.size/1024/1024).toFixed(2)} MB`:'Tap to browse phone storage';$('upload-btn').disabled=!selectedFile;});
$('upload-btn').addEventListener('click',async()=>{
  if(!projectId||!selectedFile)return;const btn=$('upload-btn');busy(btn,true,'Uploading');
  try{const fd=new FormData();fd.append('file',selectedFile);const result=await api(`/projects/${projectId}/novels`,{method:'POST',body:fd});notice('upload-notice',`Uploaded ${result.filename}\n${result.word_count.toLocaleString()} words extracted.`,'good');show('analysis-card');$('analysis-card').scrollIntoView({behavior:'smooth',block:'start'});}
  catch(e){notice('upload-notice',e.message,'error');}finally{busy(btn,false);}
});
$('analyze-btn').addEventListener('click',async()=>{
  const btn=$('analyze-btn');busy(btn,true,'Analyzing');notice('analysis-notice','AI is reading your novel and extracting story details. Keep this page open.');
  try{const response=await api(`/projects/${projectId}/analyze`,{method:'POST'});renderResult(response.result);show('result-card');notice('analysis-notice','Analysis complete. Your story bible has been saved.','good');$('result-card').scrollIntoView({behavior:'smooth',block:'start'});}
  catch(e){notice('analysis-notice',e.message,'error');}finally{busy(btn,false);}
});
function renderResult(r){$('result-title').textContent=r.title||'Your story bible';$('result-logline').textContent=r.logline||'—';$('result-synopsis').textContent=r.synopsis||'—';$('character-count').textContent=(r.characters||[]).length;$('location-count').textContent=(r.locations||[]).length;$('object-count').textContent=(r.important_objects||[]).length;
  const chips=(arr,fn)=>arr.length?arr.map(x=>`<span class="chip">${escapeHtml(fn(x))}</span>`).join(''):'<span class="muted">None extracted</span>';
  $('characters-list').innerHTML=chips(r.characters||[],x=>x.name);$('locations-list').innerHTML=chips(r.locations||[],x=>x.name);
  $('chapter-list').innerHTML=(r.chapter_breakdown||[]).map(x=>`<li>${escapeHtml(x)}</li>`).join('')||'<li>No chapter outline returned.</li>';
}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
$('new-project-btn').addEventListener('click',()=>{projectId=null;selectedFile=null;$('project-title').value='';$('novel-file').value='';$('file-label').textContent='Tap to browse phone storage';$('upload-btn').disabled=true;['upload-card','analysis-card','result-card'].forEach(hide);notice('create-notice','Ready for your next novel.','good');window.scrollTo({top:0,behavior:'smooth'});});
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));}
